<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginale0f6bf82b872605c3c11e5a0889fb708 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f6bf82b872605c3c11e5a0889fb708 = $attributes; } ?>
<?php $component = App\View\Components\PageBanner::resolve(['title' => 'Events','breadcrumbs' => [
        ['label' => 'Home', 'url' => route('index')],
        ['label' => 'Events', 'url' => '#'],
        // ['label' => ]
    ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PageBanner::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f6bf82b872605c3c11e5a0889fb708)): ?>
<?php $attributes = $__attributesOriginale0f6bf82b872605c3c11e5a0889fb708; ?>
<?php unset($__attributesOriginale0f6bf82b872605c3c11e5a0889fb708); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f6bf82b872605c3c11e5a0889fb708)): ?>
<?php $component = $__componentOriginale0f6bf82b872605c3c11e5a0889fb708; ?>
<?php unset($__componentOriginale0f6bf82b872605c3c11e5a0889fb708); ?>
<?php endif; ?>
<div class="event-details-area ptb-100" id='vanakam_da_mapla'>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="event-details">
                    <div class="event-details-header">
                        <a href="<?php echo e(route('events.index')); ?>" class="back-all-event"><i class="bx bx-chevron-left"></i> Back To All Events</a>
                        <h3><?php echo e($eventDetails->title); ?></h3>
                        <ul class="event-info-meta">
                            <li><i class="bx bx-calendar"></i> <?php echo e(\Carbon\Carbon::parse($eventDetails->date)->format('d F, Y')); ?></li>
                            <li><i class="bx bx-time"></i> <?php echo e(\Carbon\Carbon::parse($eventDetails->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($eventDetails->end_time)->format('H:i')); ?></li>
                        </ul>
                    </div>

                    <div class="event-details-image">
                        <img src="<?php echo e(asset('assets/images/events.webp')); ?>" alt="<?php echo e($eventDetails->title); ?>">
                    </div>

                    <div class="event-details-desc">
                        
                    </div>



                    <div class="event-info-links">
                        <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=<?php echo e(urlencode($eventDetails->title)); ?>&dates=<?php echo e(\Carbon\Carbon::parse($eventDetails->date . ' ' . $eventDetails->start_time)->format('Ymd\THis\Z')); ?>/<?php echo e(\Carbon\Carbon::parse($eventDetails->date . ' ' . $eventDetails->end_time)->format('Ymd\THis\Z')); ?>&details=<?php echo e(urlencode($eventDetails->description)); ?>&location=<?php echo e(urlencode($eventDetails->venue)); ?>" target="_blank">+ Google Calendar</a>
                        
                    </div>


                    <div class="post-navigation">
                        
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <aside class="widget-area" id="secondary">
                    <div class="widget widget_event_details">
                        <h3 class="widget-title">Details</h3>

                        <ul>
                            <li><span>Department:</span> <?php echo e($eventDetails->department); ?></li>
                            <li><span>Mode:</span> <?php echo e($eventDetails->mode); ?></li>
                            <li><span>Location:</span> <?php echo e($eventDetails->location); ?></li>
                            <li><span>Venue:</span> <?php echo e($eventDetails->venue); ?></li>
                            <?php if($eventDetails->price_type !== 'Idle'): ?>
    <li><span>Price Type:</span> <?php echo e($eventDetails->price_type); ?></li>
<?php else: ?>
    <li><span>Price Type:</span> Paid</li>
<?php endif; ?>

                            <li><span>Amount:</span> <?php echo e($eventDetails->amount); ?></li>
                            <li><span>Created At:</span> <?php echo e(\Carbon\Carbon::parse($eventDetails->created_at)->format('d F, Y H:i')); ?></li>
                            <li><span>Updated At:</span> <?php echo e(\Carbon\Carbon::parse($eventDetails->updated_at)->format('d F, Y H:i')); ?></li>
                        </ul>
                    </div>

                    <div class="widget widget_event_details">
                        <h3 class="widget-title">Organizer</h3>

                        <ul>
                            <li><span>Conducted By:</span> <?php echo e($eventDetails->conducted_by); ?></li>
                        </ul>
                    </div>

                    <div class="widget widget_event_details">
                        <h3 class="widget-title">Venue</h3>

                        <ul>
                            <li><a href="https://www.google.com/maps/search/?api=1&query=<?php echo e(urlencode($eventDetails->venue)); ?>" target="_blank"><?php echo e($eventDetails->venue); ?></a></li>
                            <li><a href="https://www.google.com/maps/search/?api=1&query=<?php echo e(urlencode($eventDetails->venue)); ?>" target="_blank">+ Google Map</a></li>
                        </ul>
                    </div>

                    <div class="widget widget_event_details">
                        <h3 class="widget-title">Register Here</h3>

                    <!-- Button to Open Google Sign-In -->
<div class="event-details">
    <div class="event-info-links">
        <a href="#" id="book-btn">Register</a>
    </div>
</div>

<!-- Google Sign-In Button Container -->
<div id="g_id_signin_container" style="display: none;">
    <div id="g_id_signin"
         data-client_id="3531307553-8o13atm3riuujgpa862t852k1hvqocqa.apps.googleusercontent.com"
         data-callback="handleCredentialResponse"
         data-auto_select="false">
    </div>
</div>

<!-- Include Google API script -->


                    </div>


                </aside>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://accounts.google.com/gsi/client" async defer></script>

<script>
    // Check authentication status when clicking the register button
    document.getElementById('book-btn').addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default link behavior

        axios.get('/check-auth')
            .then(response => {
                if (response.data.authenticated) {
                    window.location.href = '<?php echo e(route('register.page')); ?>';
                } else {
                    // Show the Google Sign-In button and initialize it
                    document.getElementById('g_id_signin_container').style.display = 'block';
                    initializeGoogleSignIn();
                }
            })
            .catch(error => {
                console.error('Error checking authentication:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'There was an issue checking authentication. Please try again.',
                });
            });
    });

    // Initialize Google Sign-In
    function initializeGoogleSignIn() {
        google.accounts.id.initialize({
            client_id: '3531307553-8o13atm3riuujgpa862t852k1hvqocqa.apps.googleusercontent.com',
            callback: handleCredentialResponse
        });
        google.accounts.id.renderButton(
            document.getElementById('g_id_signin'),
            { theme: 'outline', size: 'medium', type: 'standard' }  // Customize as needed
        );
    }

    // Handle Google Sign-In response
    function handleCredentialResponse(response) {
        const credential = response.credential;
        const payload = JSON.parse(atob(credential.split('.')[1]));

        // Extract user details
        const googleUid = payload.sub;
        const firstName = payload.given_name;
        const lastName = payload.family_name;
        const email = payload.email;
        const profilePicture = payload.picture;

        // Send the extracted details to the backend
        axios.post('/auth/google/callback', {
            google_uid: googleUid,
            first_name: firstName,
            last_name: lastName,
            email: email,
            profile_picture: profilePicture
        })
        .then(response => {
            if (response.data.success) {
                window.location.href = '<?php echo e(route('register.page')); ?>';
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'There was an issue logging in. Please try again.',
                });
            }
        })
        .catch(error => {
            console.error('Error logging in:', error);
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'There was an issue logging in. Please try again.',
            });
        });
    }
</script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\EGSP Projects\palanievent\plevents\resources\views/pages/show-event-details.blade.php ENDPATH**/ ?>