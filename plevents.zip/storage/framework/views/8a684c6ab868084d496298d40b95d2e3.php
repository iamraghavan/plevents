<div>
    <h4><?php echo e($event->title); ?></h4>
    <p><?php echo e($event->description); ?></p>
    <p><strong>Conducted by:</strong> <?php echo e($event->conducted_by); ?></p>
    <p><strong>Start Time:</strong> <?php echo e(\Carbon\Carbon::parse($event->start_time)->format('g:i a')); ?></p>
    <p><strong>End Time:</strong> <?php echo e(\Carbon\Carbon::parse($event->end_time)->format('g:i a')); ?></p>
    <p><strong>Venue:</strong> <?php echo e($event->venue); ?></p>
    <p><strong>Mode:</strong> <?php echo e($event->mode); ?></p>
    <p><strong>Price:</strong> <?php echo e($event->amount); ?></p>
</div>
<?php /**PATH F:\laragon\www\plevents\resources\views/partials/event-details.blade.php ENDPATH**/ ?>