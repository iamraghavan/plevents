<form action="<?php echo e(route('payment.success')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <script src="https://checkout.razorpay.com/v1/checkout.js"
            data-key="<?php echo e(env('RAZORPAY_KEY_ID')); ?>"
            data-amount="<?php echo e($amount); ?>"
            data-currency="INR"
            data-order_id="<?php echo e($order); ?>"
            data-buttontext="Pay Now">
    </script>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
</form>
<?php /**PATH F:\laragon\www\plevents\resources\views/razorpay-checkout.blade.php ENDPATH**/ ?>