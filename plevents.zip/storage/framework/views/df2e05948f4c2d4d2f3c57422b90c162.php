<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/bootstrap.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/animate.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/meanmenu.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/boxicons.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/flaticon.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/odometer.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/owl.carousel.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/owl.theme.default.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/magnific-popup.min.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/style.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("/assets/css/dark.css")); ?>">
		<link rel="stylesheet" href="<?php echo e(asset("/assets/css/responsive.css")); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<title>EGSPEC Event Conference & Community</title>

        <link rel="icon" type="image/png" href="<?php echo e(asset("/assets/images/favicon.png")); ?>">

        




    </head>
    <body>




        


        <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>



        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

        <script src="<?php echo e(asset("/assets/js/jquery.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/bootstrap.bundle.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/jquery.meanmenu.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/owl.carousel.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/jquery.appear.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/odometer.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/jquery.magnific-popup.min.js")); ?>"></script>
		<script src="<?php echo e(asset("/assets/js/jquery.ajaxchimp.min.js")); ?>"></script>
		<script src="<?php echo e(asset("/assets/js/form-validator.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/contact-form-script.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/wow.min.js")); ?>"></script>
        <script src="<?php echo e(asset("/assets/js/main.js")); ?>"></script>
        
    </body>
</html>



<?php /**PATH F:\EGSP Projects\palanievent\plevents\resources\views/layout/app.blade.php ENDPATH**/ ?>