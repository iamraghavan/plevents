<form action="<?php echo e(route('payment.make')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="submit">Pay INR</button>
</form>
<?php /**PATH F:\laragon\www\plevents\resources\views/payment-form.blade.php ENDPATH**/ ?>