<?php $__env->startSection('admin_content'); ?>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h3>Sessions</h3>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('sessions.create', ['token' => $token])); ?>" class="btn btn-primary btn-sm mb-3">
                        Create Session
                    </a>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Date</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th>Conducted By</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($session->title); ?></td>
                                        <td><?php echo e($session->date); ?></td>
                                        <td><?php echo e($session->start_time); ?></td>
                                        <td><?php echo e($session->end_time); ?></td>
                                        <td><?php echo e($session->conducted_by); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sessions.show', ['session' => $session->id, 'token' => $token])); ?>" class="btn btn-info btn-sm">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <a href="<?php echo e(route('sessions.edit', ['session' => $session->id, 'token' => $token])); ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-pencil-alt"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('sessions.destroy', ['session' => $session->id, 'token' => $token])); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\EGSP Projects\palanievent\plevents\resources\views/admin/pages/sessions/index.blade.php ENDPATH**/ ?>