<?php $__env->startSection('admin_content'); ?>
<div class="container">
    <div class="row mt-5">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h2>Admin Dashboard</h2>
                </div>
                <div class="card-body">
                    <h4>Welcome, <?php echo e($name); ?>!</h4>
                    <p>Email: <?php echo e($email); ?></p>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo e(route('sessions.index', ['token' => $token])); ?>" class="btn btn-primary btn-block">
                                View All Sessions
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-block">
                    Logout
                </button>
            </form>

            <div class="card-body">
                <h4>Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?></h4>


            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\plevents\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>